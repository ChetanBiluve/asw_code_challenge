1. In i2c.c file, correction has been done to the i2c_read and i2c_Write functions. For loop was using ++i operator, due to this first element of the buffer will not get updated. 
Hence in place of ++i, i++ operator is added.


Extra Thoughts
If you have time, answer the following questions:

1. What changes you would make to this interfaces for use in an RTOS environment?

Ans: 1. I2C API to be written as per the POSIX standard. 
	2. If BSP level calls to be used, same API definition to be used.

Note: These answers are given with respect to VxWroks7 RTOS.


2.  How might the I2C API be improved

Ans: 1. These  I2c calls are written for 1 byte wide register devices. There are some i2c Devices(EEPROM) which support 2 byte wide registers. This feature can be incorporated.
2. If it is communicating through a Hub, Hub enable/disable to be added.
3. 